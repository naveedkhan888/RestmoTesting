<?php

require_once( get_template_directory() . '/inc/backend/elementor/widgets/header/logo.php' );
require_once( get_template_directory() . '/inc/backend/elementor/widgets/header/menu.php' );
require_once( get_template_directory() . '/inc/backend/elementor/widgets/header/search.php' );
require_once( get_template_directory() . '/inc/backend/elementor/widgets/header/side-panel.php' );
require_once( get_template_directory() . '/inc/backend/elementor/widgets/header/menu-mobile.php' );
if ( class_exists( 'woocommerce' ) ) {
    require_once( get_template_directory() . '/inc/backend/elementor/widgets/header/cart.php' );
}